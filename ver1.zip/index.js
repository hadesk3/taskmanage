import mongoose from "mongoose";
import express from "express";
import flash from "express-flash";
import session from "express-session";
import cookieParser from "cookie-parser";
import path from "path";
import expressEjsLayouts from "express-ejs-layouts";
import { dirname } from "path";
import { fileURLToPath } from "url";
import homeRoute from "./router/homeRouter.js";
import authRoute from "./router/authRouter.js";
import { checkToken, getUser } from "./middlewares/auth.js";

import dotenv from "dotenv";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
dotenv.config();
const app = express();
// app.use(cors());
app.use(expressEjsLayouts);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/", express.static(path.join(__dirname, "public")));
app.use(cookieParser());
app.use(
    session({
        secret: process.env.SECRET,
        resave: false,
        saveUninitialized: true,
        // cookie: { secure: true }
    })
);

app.use(flash());

app.set("view engine", "ejs");

const url = process.env.MONGODB_URI;

mongoose
    .connect(url, {})
    .then(() => {
        console.log("Connect to db successfully:\n", url);
    })
    .catch((error) => {
        console.error("Can't connect to db:", error);
    });

// use router
app.use(getUser);
app.use("/auth", authRoute);
app.use("/", checkToken, homeRoute);

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`http://localhost:${port}`));
